import React, { useState } from 'react';
import { JobProposalForm, ThemeMode } from '../types';
import { PERSONAL_INFO } from '../data/resumeData';
import { soundFx } from '../utils/sound';
import {
  Send,
  Mail,
  Phone,
  MapPin,
  Github,
  Linkedin,
  Instagram,
  CheckCircle2,
  Copy,
  Check,
  Building,
  DollarSign,
  Sparkles,
  Terminal,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ConnectSectionProps {
  theme: ThemeMode;
}

export const ConnectSection: React.FC<ConnectSectionProps> = ({ theme }) => {
  const isDark = theme === 'dark';
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [transmitting, setTransmitting] = useState(false);
  const [transmitted, setTransmitted] = useState(false);
  const [progressStep, setProgressStep] = useState(0);

  const [form, setForm] = useState<JobProposalForm>({
    senderName: '',
    senderEmail: '',
    companyName: '',
    proposalType: 'Full-time',
    budgetRange: '$2,000 - $4,000 / mes',
    techRequired: ['React Native', 'Node.js'],
    message: '',
  });

  const availableTechs = ['React Native', 'Flutter', 'Expo', 'Android Studio', 'Node.js', 'Express', 'Laravel', 'Python / IA', 'PostgreSQL'];

  const handleCopyEmail = () => {
    soundFx.playClick();
    navigator.clipboard.writeText(PERSONAL_INFO.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleToggleTech = (tech: string) => {
    soundFx.playClick();
    setForm((prev) => {
      const exists = prev.techRequired.includes(tech);
      return {
        ...prev,
        techRequired: exists
          ? prev.techRequired.filter((t) => t !== tech)
          : [...prev.techRequired, tech],
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.senderName || !form.senderEmail || !form.message) return;

    soundFx.playTransmit();
    setTransmitting(true);
    setTransmitted(false);
    setProgressStep(1);

    setTimeout(() => setProgressStep(2), 600);
    setTimeout(() => setProgressStep(3), 1200);
    setTimeout(() => {
      setTransmitting(false);
      setTransmitted(true);
      soundFx.playClick();
    }, 1800);
  };

  return (
    <div id="section-connect" className="space-y-10 pb-12">
      {/* Header Banner */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="space-y-2 border-b pb-4 border-slate-800/60"
      >
        <div className="flex items-center space-x-3">
          <span className="h-3 w-1 bg-emerald-400 rounded-full animate-pulse" />
          <h1 className="text-2xl sm:text-4xl font-mono font-extrabold tracking-tight">
            <span className={isDark ? 'text-slate-200' : 'text-slate-800'}>PROPOSAL </span>
            <span className="text-emerald-400 drop-shadow-[0_0_12px_rgba(52,211,153,0.5)]">UPLINK</span>
          </h1>
        </div>
        <p className={`font-mono text-xs sm:text-sm ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
          Formulario optimizado para recepción de propuestas laborales, ofertas de contratación y proyectos de desarrollo móvil / IA.
        </p>
      </motion.div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Direct Contact Info & Socials */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="lg:col-span-5 space-y-6"
        >
          {/* Direct Card */}
          <div className={`p-6 rounded-2xl border font-mono space-y-5 ${
            isDark ? 'bg-[#0f172a]/90 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
          }`}>
            <div className="flex items-center space-x-2 text-xs text-emerald-400 font-bold uppercase tracking-wider">
              <Terminal className="w-4 h-4" />
              <span>DIRECT_TRANSMISSION_INFO</span>
            </div>

            <div className="space-y-4 text-xs font-sans">
              {/* Email with copy button */}
              <div className="p-3 rounded-xl border border-slate-800 bg-[#0d1322] flex items-center justify-between font-mono">
                <div className="flex items-center space-x-3">
                  <Mail className="w-4 h-4 text-cyan-400" />
                  <div>
                    <div className="text-[10px] text-slate-500">CORREO ELECTRÓNICO</div>
                    <div className="text-xs text-slate-200 font-bold">{PERSONAL_INFO.email}</div>
                  </div>
                </div>

                <button
                  id="copy-email-btn"
                  onClick={handleCopyEmail}
                  className="p-2 rounded bg-slate-800 text-slate-300 hover:text-cyan-300"
                  title="Copiar Correo"
                >
                  {copiedEmail ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Phone / WhatsApp */}
              <a
                id="phone-whatsapp-link"
                href={`https://wa.me/593979314381`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-xl border border-slate-800 bg-[#0d1322] flex items-center justify-between font-mono hover:border-emerald-500 transition-colors block"
              >
                <div className="flex items-center space-x-3">
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <div>
                    <div className="text-[10px] text-slate-500">TELÉFONO / WHATSAPP</div>
                    <div className="text-xs text-slate-200 font-bold">{PERSONAL_INFO.phone}</div>
                  </div>
                </div>
                <span className="text-[10px] text-emerald-400 font-bold">WHATSAPP →</span>
              </a>

              {/* Location */}
              <div className="p-3 rounded-xl border border-slate-800 bg-[#0d1322] flex items-center space-x-3 font-mono">
                <MapPin className="w-4 h-4 text-fuchsia-400" />
                <div>
                  <div className="text-[10px] text-slate-500">UBICACIÓN GEOGRÁFICA</div>
                  <div className="text-xs text-slate-200 font-bold">{PERSONAL_INFO.location}</div>
                </div>
              </div>
            </div>

            {/* Social Links Grid */}
            <div className="pt-4 border-t border-slate-800 space-y-2">
              <div className="text-[10px] text-slate-500 font-mono uppercase tracking-widest">REDES SOCIALES Y PERFILES</div>
              <div className="grid grid-cols-3 gap-2 font-mono text-xs">
                <a
                  id="connect-github-btn"
                  href={PERSONAL_INFO.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/60 hover:border-cyan-400 hover:text-cyan-300 flex flex-col items-center justify-center text-slate-300 transition-all"
                >
                  <Github className="w-4 h-4 mb-1" />
                  <span className="text-[10px]">GitHub</span>
                </a>

                <a
                  id="connect-linkedin-btn"
                  href={PERSONAL_INFO.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/60 hover:border-blue-400 hover:text-blue-300 flex flex-col items-center justify-center text-slate-300 transition-all"
                >
                  <Linkedin className="w-4 h-4 mb-1 text-blue-400" />
                  <span className="text-[10px]">LinkedIn</span>
                </a>

                <a
                  id="connect-instagram-btn"
                  href={PERSONAL_INFO.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-lg border border-slate-800 bg-slate-900/60 hover:border-fuchsia-400 hover:text-fuchsia-300 flex flex-col items-center justify-center text-slate-300 transition-all"
                >
                  <Instagram className="w-4 h-4 mb-1 text-fuchsia-400" />
                  <span className="text-[10px]">Instagram</span>
                </a>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Right Job Proposal Form */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="lg:col-span-7"
        >
          <div className={`p-6 rounded-2xl border font-mono ${
            isDark ? 'bg-[#0a0f1d] border-emerald-500/40 shadow-[0_0_20px_rgba(52,211,153,0.1)]' : 'bg-white border-slate-200 shadow-md'
          }`}>
            <h2 className="text-xl font-bold text-slate-100 mb-1 flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              <span>ENVIAR PROPUESTA LABORAL</span>
            </h2>
            <p className="text-xs text-slate-400 font-sans mb-6">
              Completa los datos de tu oferta o proyecto. Recibirás respuesta directa en menos de 24 horas.
            </p>

            <AnimatePresence mode="wait">
              {transmitted ? (
                <motion.div
                  key="success"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-6 rounded-xl border border-emerald-500/50 bg-emerald-950/20 text-center space-y-4"
                >
                  <div className="w-12 h-12 rounded-full bg-emerald-500 text-black mx-auto flex items-center justify-center shadow-[0_0_20px_rgba(52,211,153,0.6)]">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <h3 className="text-lg font-bold text-emerald-300">PROPUESTA TRANSMITIDA CON ÉXITO</h3>
                  <p className="text-xs text-slate-300 font-sans leading-relaxed max-w-md mx-auto">
                    Gracias <span className="font-bold text-white">{form.senderName}</span>. Tu mensaje y especificación de proyecto han sido encriptados y entregados a <span className="text-cyan-300">{PERSONAL_INFO.email}</span>.
                  </p>

                  <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-400 text-left font-mono max-w-md mx-auto">
                    <div>• TIPO DE OFERTA: {form.proposalType}</div>
                    <div>• RANGO: {form.budgetRange}</div>
                    <div>• STACK: {form.techRequired.join(', ')}</div>
                  </div>

                  <button
                    id="new-proposal-btn"
                    onClick={() => {
                      setTransmitted(false);
                      setForm({
                        senderName: '',
                        senderEmail: '',
                        companyName: '',
                        proposalType: 'Full-time',
                        budgetRange: '$2,000 - $4,000 / mes',
                        techRequired: ['React Native', 'Node.js'],
                        message: '',
                      });
                    }}
                    className="px-5 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs"
                  >
                    ENVIAR OTRA CONSULTA
                  </button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Name and Email */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-slate-300 font-bold block mb-1">
                        NOMBRE COMPLETO *
                      </label>
                      <input
                        id="form-sender-name"
                        type="text"
                        required
                        placeholder="Ej. Ing. María López"
                        value={form.senderName}
                        onChange={(e) => setForm({ ...form, senderName: e.target.value })}
                        className={`w-full px-3 py-2 rounded-lg border font-sans text-xs ${
                          isDark
                            ? 'bg-[#0d1322] border-slate-800 text-slate-200 focus:border-emerald-400 focus:outline-none'
                            : 'bg-slate-50 border-slate-300 text-slate-800 focus:border-emerald-600 focus:outline-none'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-xs text-slate-300 font-bold block mb-1">
                        CORREO DE CONTACTO *
                      </label>
                      <input
                        id="form-sender-email"
                        type="email"
                        required
                        placeholder="ejemplo@empresa.com"
                        value={form.senderEmail}
                        onChange={(e) => setForm({ ...form, senderEmail: e.target.value })}
                        className={`w-full px-3 py-2 rounded-lg border font-sans text-xs ${
                          isDark
                            ? 'bg-[#0d1322] border-slate-800 text-slate-200 focus:border-emerald-400 focus:outline-none'
                            : 'bg-slate-50 border-slate-300 text-slate-800 focus:border-emerald-600 focus:outline-none'
                        }`}
                      />
                    </div>
                  </div>

                  {/* Company Name & Offer Type */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs text-slate-300 font-bold block mb-1">
                        EMPRESA / INSTITUCIÓN
                      </label>
                      <input
                        id="form-company-name"
                        type="text"
                        placeholder="Ej. Tech Solutions Corp"
                        value={form.companyName}
                        onChange={(e) => setForm({ ...form, companyName: e.target.value })}
                        className={`w-full px-3 py-2 rounded-lg border font-sans text-xs ${
                          isDark
                            ? 'bg-[#0d1322] border-slate-800 text-slate-200 focus:border-emerald-400 focus:outline-none'
                            : 'bg-slate-50 border-slate-300 text-slate-800 focus:border-emerald-600 focus:outline-none'
                        }`}
                      />
                    </div>

                    <div>
                      <label className="text-xs text-slate-300 font-bold block mb-1">
                        TIPO DE PROPUESTA *
                      </label>
                      <select
                        id="form-proposal-type"
                        value={form.proposalType}
                        onChange={(e) =>
                          setForm({
                            ...form,
                            proposalType: e.target.value as JobProposalForm['proposalType'],
                          })
                        }
                        className={`w-full px-3 py-2 rounded-lg border font-mono text-xs ${
                          isDark
                            ? 'bg-[#0d1322] border-slate-800 text-slate-200 focus:border-emerald-400 focus:outline-none'
                            : 'bg-slate-50 border-slate-300 text-slate-800 focus:border-emerald-600 focus:outline-none'
                        }`}
                      >
                        <option value="Full-time">Contratación Tiempo Completo (Full-time)</option>
                        <option value="Freelance / Contract">Proyecto Freelance / Contrato</option>
                        <option value="Mobile App Development">Desarrollo App Móvil a Medida</option>
                        <option value="AI Consulting">Consultoría de Inteligencia Artificial</option>
                        <option value="Other">Otro / Consulta General</option>
                      </select>
                    </div>
                  </div>

                  {/* Tech Required Checkboxes */}
                  <div>
                    <label className="text-xs text-slate-300 font-bold block mb-2">
                      TECNOLOGÍAS / MÓDULOS REQUERIDOS:
                    </label>
                    <div className="flex flex-wrap gap-1.5">
                      {availableTechs.map((tech) => {
                        const selected = form.techRequired.includes(tech);
                        return (
                          <button
                            type="button"
                            key={tech}
                            id={`tech-checkbox-${tech.replace(/\s+/g, '-').toLowerCase()}`}
                            onClick={() => handleToggleTech(tech)}
                            className={`px-2.5 py-1 rounded text-[11px] border transition-all ${
                              selected
                                ? 'bg-emerald-950 text-emerald-300 border-emerald-400 font-bold'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            {selected ? '✓ ' : '+ '}
                            {tech}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Message details */}
                  <div>
                    <label className="text-xs text-slate-300 font-bold block mb-1">
                      DETALLES DE LA PROPUESTA / DESCRIPCIÓN DEL PROYECTO *
                    </label>
                    <textarea
                      id="form-message"
                      required
                      rows={4}
                      placeholder="Describe el rol, objetivos de la app, alcance estimado y plazos..."
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      className={`w-full px-3 py-2 rounded-lg border font-sans text-xs ${
                        isDark
                          ? 'bg-[#0d1322] border-slate-800 text-slate-200 focus:border-emerald-400 focus:outline-none'
                          : 'bg-slate-50 border-slate-300 text-slate-800 focus:border-emerald-600 focus:outline-none'
                      }`}
                    />
                  </div>

                  {/* Submit button */}
                  <button
                    id="submit-proposal-btn"
                    type="submit"
                    disabled={transmitting}
                    className="w-full py-3 rounded-xl border border-emerald-400 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm transition-all duration-300 shadow-[0_0_20px_rgba(52,211,153,0.3)] flex items-center justify-center space-x-2"
                  >
                    {transmitting ? (
                      <>
                        <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                        <span>ESTABLECIENDO ENLACE ENCRIPTADO... ({progressStep}/3)</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>TRANSMITIR PROPUESTA LABORAL</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
