import React from 'react';
import { ThemeMode } from '../types';
import { PERSONAL_INFO } from '../data/resumeData';
import { soundFx } from '../utils/sound';
import { Github, Linkedin, Instagram, Mail, Heart, Terminal } from 'lucide-react';

interface FooterProps {
  theme: ThemeMode;
}

export const Footer: React.FC<FooterProps> = ({ theme }) => {
  const isDark = theme === 'dark';

  return (
    <footer
      id="main-footer"
      className={`border-t font-mono text-xs transition-colors duration-300 ${
        isDark
          ? 'bg-[#060911] border-[#182234] text-slate-400'
          : 'bg-slate-900 border-slate-800 text-slate-300'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Left Brand info */}
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-400 font-bold">
              RV
            </div>
            <div>
              <div className="font-bold text-white tracking-wider">
                SYSTEM_CORE // {PERSONAL_INFO.shortName}
              </div>
              <div className="text-[11px] text-slate-500">
                {PERSONAL_INFO.degree}
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="flex items-center space-x-4">
            <a
              id="footer-github"
              href={PERSONAL_INFO.github}
              target="_blank"
              rel="noopener noreferrer"
              onMouseEnter={() => soundFx.playHover()}
              className="p-2 rounded hover:bg-slate-800 hover:text-cyan-400 transition-colors"
              title="GitHub"
            >
              <Github className="w-4 h-4" />
            </a>

            <a
              id="footer-linkedin"
              href={PERSONAL_INFO.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              onMouseEnter={() => soundFx.playHover()}
              className="p-2 rounded hover:bg-slate-800 hover:text-blue-400 transition-colors"
              title="LinkedIn"
            >
              <Linkedin className="w-4 h-4" />
            </a>

            <a
              id="footer-instagram"
              href={PERSONAL_INFO.instagram}
              target="_blank"
              rel="noopener noreferrer"
              onMouseEnter={() => soundFx.playHover()}
              className="p-2 rounded hover:bg-slate-800 hover:text-fuchsia-400 transition-colors"
              title="Instagram"
            >
              <Instagram className="w-4 h-4" />
            </a>

            <a
              id="footer-email"
              href={`mailto:${PERSONAL_INFO.email}`}
              onMouseEnter={() => soundFx.playHover()}
              className="p-2 rounded hover:bg-slate-800 hover:text-emerald-400 transition-colors"
              title="Email"
            >
              <Mail className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-4 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-500">
          <div>
            © 2026 {PERSONAL_INFO.fullName}. ALL RIGHTS RESERVED.
          </div>
          <div className="flex items-center space-x-1">
            <span>BUILT WITH REACT, TAILWIND & MOTION</span>
            <span className="text-cyan-400 font-bold">// QUITO, ECUADOR</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
