import { Project, Experience, TechCategory, Certification, BlogPost } from '../types';

export const PERSONAL_INFO = {
  fullName: 'RICHARD ALEXIS VIVANCO CHICAIZA',
  shortName: 'RICHARD VIVANCO',
  title: 'Mobile Specialist & Full Stack Developer',
  degree: 'Ingeniería de Software — Universidad de las Fuerzas Armadas ESPE-L (Egresado)',
  location: 'Quito, Ecuador',
  phone: '(+593) 979 314 381',
  email: 'rvivanco199@gmail.com',
  github: 'https://github.com/ravivanco',
  githubUsername: 'ravivanco',
  linkedin: 'https://linkedin.com/in/richard-vivanco',
  linkedinUsername: 'richard-vivanco',
  instagram: 'https://www.instagram.com/richarfd199/',
  instagramUsername: 'richarfd199',
  stats: {
    commits: '1.2K+',
    contributions: '500+',
    linesOfCode: '50K+',
    followers: '100+',
    projects: '12+',
    repos: '25+',
  },
  bio: 'Ingeniero de Software egresado de la Universidad de las Fuerzas Armadas ESPE, especializado en desarrollo móvil con experiencia complementaria en desarrollo backend y web full stack. He construido aplicaciones con integración de inteligencia artificial para reconocimiento de imágenes y recomendación de contenido, así como soluciones móviles para movilidad urbana y delivery. Combino formación técnica sólida en arquitectura de software y bases de datos con capacidad de adaptación rápida a nuevas metodologías, herramientas y equipos ágiles, orientando siempre mi trabajo a construir productos funcionales, escalables y centrados en el usuario.',
  motto: 'Construyendo el presente, diseñando el futuro.',
};

export const EXPERIENCES: Experience[] = [
  {
    id: 'exp-1',
    role: 'Desarrollador Móvil — Prácticas Preprofesionales',
    company: 'Kaizen Software',
    period: 'Oct. 2025',
    location: 'Quito, Ecuador',
    type: 'Prácticas Preprofesionales',
    bullets: [
      'Desarrollo de una aplicación móvil de delivery utilizando React Native y Expo, cubriendo flujos de pedido, seguimiento en tiempo real y gestión de usuarios.',
      'Implementación y prueba de módulos nativos con Android Studio para garantizar alta compatibilidad, optimización de memoria y rendimiento en dispositivos Android.',
      'Colaboración directa con el equipo técnico bajo metodologías ágiles (Scrum), participando activamente en revisiones de código, sprints y entregas incrementales.'
    ],
    techUsed: ['React Native', 'Expo', 'Android Studio', 'JavaScript', 'Scrum', 'Git']
  },
  {
    id: 'exp-2',
    role: 'Desarrollador Móvil — Proyecto de Vinculación',
    company: 'PROWESS BIKE',
    period: 'Ago. 2023',
    location: 'Quito, Ecuador',
    type: 'Proyecto de Vinculación',
    bullets: [
      'Desarrollo del módulo móvil de la aplicación con Flutter y Android Studio, enfocado en la experiencia de usuario para gestión de rutas y bicicletas.',
      'Participación en el diseño de la interfaz de usuario (UI/UX) y la lógica de negocio de la app, coordinando con el equipo multidisciplinario del proyecto universitario.',
      'Integración con servicios cartográficos de Google Maps API para trazado interactivo de recorridos ciclistas y cálculo de distancias.'
    ],
    techUsed: ['Flutter', 'Dart', 'Android Studio', 'Google Maps API', 'Mobile UX']
  },
  {
    id: 'exp-3',
    role: 'Desarrollador Full Stack',
    company: 'NYC Arquitectos',
    period: 'Ago. 2021',
    location: 'Quito, Ecuador',
    type: 'Freelance / Proyecto',
    bullets: [
      'Diseño y desarrollo integral del sitio web corporativo del estudio de arquitectura, cubriendo tanto el frontend responsivo como la API backend.',
      'Implementación de funcionalidades a medida para presentar portafolios interactivos de proyectos arquitectónicos y un gestor de contenidos dinámico.',
      'Optimización de carga SEO, estructuras visuales elegantes y maquetación adaptada a dispositivos móviles y de escritorio.'
    ],
    techUsed: ['React', 'Node.js', 'Express', 'Tailwind CSS', 'JavaScript', 'MySQL']
  }
];

export const PROJECTS: Project[] = [
  {
    id: 'dk-fitt',
    title: 'DK-Fitt',
    subtitle: 'Proyecto de Titulación: App móvil de control nutricional con IA',
    category: 'ai',
    date: 'Feb. 2026',
    description: 'Aplicación móvil de control nutricional de vanguardia que integra visión por computadora para el reconocimiento de alimentos mediante fotografías y un motor de inteligencia artificial que genera planes alimenticios personalizados.',
    bullets: [
      'Reconocimiento instantáneo de alimentos por fotografía mediante Inteligencia Artificial (Computer Vision).',
      'Motor de recomendación de menús personalizados con IA como herramienta de apoyo para nutricionistas y usuarios.',
      'Diseño end-to-end del producto: desde el modelo de reconocimiento visual hasta la experiencia de usuario móvil fluida.'
    ],
    techStack: ['React Native', 'Node.js', 'PostgreSQL', 'IA Vision', 'Cloudinary', 'Expo'],
    imageUrl: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=1200&q=80',
    githubUrl: 'https://github.com/ravivanco/DK-Fitt',
    hasAiDemo: true
  },
  {
    id: 'nutrisportiff',
    title: 'NutriSportiff',
    subtitle: 'Proyecto académico — cálculo de IMC y recomendación nutricional',
    category: 'mobile',
    date: 'Feb. 2025',
    description: 'Aplicación multiplataforma diseñada para deportistas y entusiastas de la salud. Permite el cálculo automatizado del Índice de Masa Corporal (IMC), métricas antropométricas y la generación de pautas nutricionales.',
    bullets: [
      'Cálculo preciso del Índice de Masa Corporal (IMC) e historial evolutivo del usuario.',
      'Generación de recomendaciones alimenticias personalizadas con arquitectura respaldada en la nube.',
      'Sincronización en tiempo real con base de datos Firebase para almacenamiento de perfiles corporales.'
    ],
    techStack: ['Flutter', 'Dart', 'Firebase', 'Android Studio'],
    imageUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=1200&q=80',
    githubUrl: 'https://github.com/ravivanco/NutriSportiff'
  },
  {
    id: 'prowess-bike',
    title: 'PROWESS BIKE',
    subtitle: 'Proyecto de Vinculación — Gestión de rutas y ciclismo urbano',
    category: 'mobile',
    date: 'Ago. 2023',
    description: 'Módulo móvil especializado para ciclistas urbanos que facilita la exploración, trazado y guardado de rutas ciclistas, además de la administración del mantenimiento de bicicletas.',
    bullets: [
      'Módulo móvil para gestión de rutas de ciclismo e integración con la API de Google Maps.',
      'Diseño enfocado en la usabilidad en campo, garantizando visualización clara bajo la luz solar.',
      'Coordinación interinstitucional para el proyecto de vinculación comunitaria universitaria.'
    ],
    techStack: ['Flutter', 'Android Studio', 'Google Maps API', 'Dart'],
    imageUrl: 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=1200&q=80',
    githubUrl: 'https://github.com/ravivanco/PROWESS-BIKE'
  },
  {
    id: 'kaizen-delivery',
    title: 'Kaizen Delivery App',
    subtitle: 'Solución Móvil de Logística y Pedidos en Tiempo Real',
    category: 'mobile',
    date: 'Oct. 2025',
    description: 'Aplicación móvil de logística y envíos construida durante las prácticas en Kaizen Software, enfocada en la rapidez de transmisión de estados y la ergonomía del usuario repartidor.',
    bullets: [
      'Flujos completos de creación de pedidos, rastreo con geolocalización y notificaciones.',
      'Integración de controladores nativos Android con Android Studio para optimización de GPS.',
      'Arquitectura orientada a eventos para cambios de estado de paquetes en tiempo real.'
    ],
    techStack: ['React Native', 'Expo', 'Android Studio', 'Node.js', 'Express'],
    imageUrl: 'https://images.unsplash.com/photo-1526367790999-0150786686a2?auto=format&fit=crop&w=1200&q=80',
    githubUrl: 'https://github.com/ravivanco'
  },
  {
    id: 'nyc-arquitectos',
    title: 'NYC Arquitectos Web',
    subtitle: 'Plataforma Corporativa y Portafolio Full Stack',
    category: 'fullstack',
    date: 'Ago. 2021',
    description: 'Portal web profesional desarrollado a medida para NYC Arquitectos, permitiendo la exhibición de renders 3D, proyectos finalizados y contacto directo con clientes.',
    bullets: [
      'Frontend moderno con galería dinámica interactivas y filtros por categoría arquitectónica.',
      'Backend liviano para la administración de obras, imágenes y mensajes de clientes.',
      'Maquetación responsiva de alta estética visual adaptada al estándar de estudios de arquitectura.'
    ],
    techStack: ['React', 'Node.js', 'Express', 'Tailwind CSS', 'MySQL'],
    imageUrl: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    githubUrl: 'https://github.com/ravivanco'
  }
];

export const TECH_CATEGORIES: TechCategory[] = [
  {
    title: 'Desarrollo Móvil',
    skills: [
      { name: 'React Native', badge: 'Experto' },
      { name: 'Flutter', badge: 'Experto' },
      { name: 'Expo', badge: 'Avanzado' },
      { name: 'Android Studio', badge: 'Avanzado' }
    ]
  },
  {
    title: 'Backend & Web',
    skills: [
      { name: 'Node.js', badge: 'Avanzado' },
      { name: 'Express', badge: 'Avanzado' },
      { name: 'Laravel', badge: 'Intermedio' },
      { name: 'Spring Boot', badge: 'Intermedio' },
      { name: 'Python', badge: 'Avanzado' }
    ]
  },
  {
    title: 'Frontend / Web',
    skills: [
      { name: 'React', badge: 'Avanzado' },
      { name: 'JavaScript', badge: 'Experto' },
      { name: 'HTML5', badge: 'Experto' },
      { name: 'Tailwind CSS', badge: 'Avanzado' },
      { name: 'Bootstrap', badge: 'Avanzado' }
    ]
  },
  {
    title: 'Lenguajes',
    skills: [
      { name: 'Java', badge: 'Avanzado' },
      { name: 'JavaScript / TS', badge: 'Experto' },
      { name: 'Python', badge: 'Avanzado' },
      { name: 'C#', badge: 'Intermedio' },
      { name: 'C++', badge: 'Intermedio' }
    ]
  },
  {
    title: 'Bases de Datos',
    skills: [
      { name: 'PostgreSQL', badge: 'Avanzado' },
      { name: 'MySQL', badge: 'Avanzado' },
      { name: 'MongoDB', badge: 'Intermedio' },
      { name: 'phpMyAdmin', badge: 'Avanzado' }
    ]
  },
  {
    title: 'IA & Automatización',
    skills: [
      { name: 'Reconocimiento de Imágenes (Vision AI)', badge: 'Core' },
      { name: 'Motores de Recomendación', badge: 'Core' },
      { name: 'Automatización N8N', badge: 'Avanzado' },
      { name: 'Integración LLM / Gemini', badge: 'Avanzado' }
    ]
  }
];

export const CERTIFICATIONS: Certification[] = [
  {
    title: 'Fundamentos de Ciberseguridad',
    issuer: 'Universidad de las Fuerzas Armadas ESPE',
    year: '2025',
    iconName: 'ShieldCheck'
  },
  {
    title: 'Ciencia de Datos y Machine Learning aplicado a la Ciberseguridad',
    issuer: 'Universidad de las Fuerzas Armadas ESPE',
    year: '2025',
    iconName: 'Cpu'
  }
];

export const LANGUAGES = [
  { name: 'Español', level: 'Nativo // MAX' },
  { name: 'Inglés', level: 'Nivel B1 // MID' }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'post-1',
    title: 'Integración de Visión por Computadora en Dispositivos Móviles: El Caso DK-Fitt',
    summary: 'Cómo conectamos modelos de clasificación e identificación de alimentos por fotografía con una arquitectura móvil React Native y backend Node.js en tiempo real.',
    category: 'AI & ML',
    date: '10 Feb 2026',
    readTime: '6 min lectura',
    tags: ['Computer Vision', 'React Native', 'Node.js', 'AI Nutrition'],
    content: `
### Introducción

El proyecto **DK-Fitt** nació de la necesidad de simplificar el seguimiento nutricional para usuarios y nutricionistas. El mayor obstáculo en la medición dietética es el registro manual.

### Arquitectura de Reconocimiento Visual

Implementamos un pipeline de inferencia optimizado:
1. **Captura Móvil**: Compresión de imagen client-side con Expo Camera para minimizar latencia.
2. **Streaming a API Gateway**: Transmisión multipart/form-data hacia nuestro microservicio Node.js.
3. **Pipeline de Inferencia**: Procesamiento mediante modelo de Visión especializado en segmentación gastronómica.
4. **Respuesta Estructurada**: Retorno de alimentos detectados, probabilidad de confianza y estimación de macronutrientes.

\`\`\`typescript
// Fragmento de envío de fotografía en React Native
async function analyzeFoodImage(imageUri: string) {
  const formData = new FormData();
  formData.append('photo', {
    uri: imageUri,
    type: 'image/jpeg',
    name: 'meal_scan.jpg',
  } as any);

  const response = await fetch('/api/vision/analyze-meal', {
    method: 'POST',
    body: formData,
  });
  return response.json();
}
\`\`\`

### Conclusiones y Futuro
Esta integración redujo el tiempo de registro alimenticio de 3 minutos a menos de 4 segundos por plato, logrando una precisión promedio del 92% en pruebas de campo.
    `
  },
  {
    id: 'post-2',
    title: 'Módulos Nativos en Android Studio para Apps React Native & Expo',
    summary: 'Guía práctica basada en mi experiencia en Kaizen Software sobre cuándo y cómo invocar capacidades nativas de Android sin comprometer la agilidad de Expo.',
    category: 'Mobile',
    date: '15 Nov 2025',
    readTime: '5 min lectura',
    tags: ['React Native', 'Android Studio', 'Expo', 'Native Modules'],
    content: `
### ¿Por qué recurrir a Módulos Nativos?

Aunque Expo ofrece una excelente suite de APIs out-of-the-box, aplicaciones avanzadas de logística y delivery requieren optimización directa de memoria, sensores GPS en background y drivers de hardware específicos.

### Pasos Clave en Android Studio

1. **Configuración del Expo Prebuild**: Generar la carpeta \`android/\` limpia.
2. **Creación del Java/Kotlin Package**: Registrar el módulo exponiendo metodos anotados con \`@ReactMethod\`.
3. **Manejo de Hilos**: Ejecutar procesos pesados en hilos secundarios para no congelar la UI de React Native.

\`\`\`java
@ReactMethod
public void startHighPrecisionGPS(Promise promise) {
    try {
        LocationManager.startService();
        promise.resolve("GPS_NATIVE_ACTIVE");
    } catch (Exception e) {
        promise.reject("ERR_GPS", e.getMessage());
    }
}
\`\`\`
    `
  },
  {
    id: 'post-3',
    title: 'Automatización de Workflows con N8N e Integración de Microservicios',
    summary: 'Exploración de N8N para conectar webhooks de pedidos de delivery, alertas de usuario y servicios en la nube de forma ágil y mantenible.',
    category: 'Backend',
    date: '02 Sep 2025',
    readTime: '4 min lectura',
    tags: ['N8N', 'Automation', 'Python', 'Webhooks'],
    content: `
### El poder de la Automatización No-Code / Low-Code

Durante la construcción de pipelines de datos y notificaciones, N8N permite desacoplar tareas pesadas como el envío de correos, generación de reportes PDF y webhook callbacks sin saturar el servidor principal Express.

### Casos de Uso Implementados
* **Notificaciones de Pedidos**: Disparo automático hacia Telegram y SMS al cambiar estado de delivery.
* **Transformación de Datos**: Scripts Python embebidos en nodos N8N para limpiar entradas JSON antes de persistir en PostgreSQL.
    `
  },
  {
    id: 'post-4',
    title: 'Aplicación de Machine Learning y Ciberseguridad en la Nube',
    summary: 'Conceptos clave aprendidos en la certificación de la Universidad ESPE sobre detección de anomalías y protección de APIs móviles.',
    category: 'Cybersecurity',
    date: '18 Jul 2025',
    readTime: '7 min lectura',
    tags: ['Cybersecurity', 'Machine Learning', 'ESPE', 'API Security'],
    content: `
### Detección de Amenazas en Puntos de Entrada Móviles

Las APIs REST expuestas a aplicaciones móviles deben resguardarse contra bots, peticiones maliciosas e inyecciones.

### Principales Recomendaciones
* **Certificate Pinning**: Previene ataques Man-In-The-Middle en comunicaciones móviles.
* **Modelos de Clasificación**: Entrenamiento con scikit-learn para identificar patrones anómalos de tráfico API.
* **Encriptación de Token Bearer**: Rotación constante de llaves JWT y validación en middleware Express.
    `
  }
];
